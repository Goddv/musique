# Qt Idle library

This simple Qt library manages system and display sleep on Mac, Windows and Linux. Contributions for other platforms are welcome.

You can use this library under the MIT license and at your own risk. If you do, you're welcome contributing your changes and fixes.

Cheers,

Flavio