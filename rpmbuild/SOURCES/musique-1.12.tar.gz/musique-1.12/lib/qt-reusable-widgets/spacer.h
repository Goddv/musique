#ifndef SPACER_H
#define SPACER_H

#include <QtWidgets/QWidget>

class Spacer : public QWidget {
public:
    Spacer(QWidget *parent = nullptr);
};

#endif // SPACER_H
