#ifndef UPDATEUTILS_H
#define UPDATEUTILS_H

namespace UpdateUtils {

void init();

};

#endif // UPDATEUTILS_H
