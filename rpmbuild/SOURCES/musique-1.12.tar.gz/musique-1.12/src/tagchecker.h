#ifndef TAGCHECKER_H
#define TAGCHECKER_H

class Tags;

namespace TagChecker {

    bool checkTags(Tags *tags);

}

#endif // TAGCHECKER_H
